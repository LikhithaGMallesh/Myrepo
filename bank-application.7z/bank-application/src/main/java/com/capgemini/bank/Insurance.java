package com.capgemini.bank;

public interface Insurance {
	
	public void display();
	
	

}
