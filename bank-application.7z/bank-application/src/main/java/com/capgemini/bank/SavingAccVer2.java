package com.capgemini.bank;



public class SavingAccVer2 extends SavingAccount implements  Insurance {

/*	public void withdraw(double amount) {
   System.out.println("Withdraw amount");
		
	}
*/
	public void deposit(double amount) {
		
		System.out.println("Withdraw amount");
	}

	public void display() {
		System.out.println("hello");
		
	}

}
