package com.capgemini.bank;

public class SavingAccount  extends BankAccount {
	
	
	@Override
	public void withdraw(double amount) {
	
      System.out.println("Saving account Withdraw method");
}

}
