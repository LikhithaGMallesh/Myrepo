package com.pluralsight.tddjunit5.airconditioning;

public class Sensor {

    private boolean blocked;

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }
}
